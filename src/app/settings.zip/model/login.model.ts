export interface LoginModel{
    email_id?:string,
    password?:string,
    device_id?:string,
    os_type?:number,
    registration_id?:string,
    // school_id?:string
}